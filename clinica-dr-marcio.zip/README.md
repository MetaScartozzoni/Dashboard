
# Clínica Dr. Marcio – Sistema Integrado

Este projeto é o painel visual e funcional da Clínica Dr. Marcio Scartozzoni.

## ✅ Funcionalidades
- Visão geral do dia com calendário de compromissos
- Recados e pendências com integração à planilha
- Botão de entrada para iniciar os atendimentos
- Totalmente responsivo e adaptado para iPad
- Integração com Google Sheets e WebApps

## 🚀 Como subir no Vercel

1. Suba este repositório para o seu GitHub
2. Vá até [https://vercel.com/import](https://vercel.com/import)
3. Clique em "Import Git Repository" e selecione este projeto
4. Pronto! O Vercel detecta automaticamente o Next.js

---

**Tecnologias**: Next.js, TailwindCSS, Google Sheets, WebApps

Feito com ❤️ para o dia a dia da Clínica
